# بناء AAB للمسبار
1. ضع `almisbar-upload.jks` و`keystore.properties` في جذر المشروع.
2. شغّل: `gradle :app:bundleRelease`
3. الناتج: `app/build/outputs/bundle/release/app-release.aab`

معرّف التطبيق com.taroot.almisbar لا يتغير بعد أول رفع. احتفظ بمفتاح التوقيع؛ كل تحديث يحتاج إليه.
